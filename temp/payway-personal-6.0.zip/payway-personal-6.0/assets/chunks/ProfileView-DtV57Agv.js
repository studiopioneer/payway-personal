import{_ as X,y as D,r as u,m as Y,o as i,c as f,a as o,t as p,f as h,e as R,s as O,v as B,g as Z,i as C,G as ee,P as se,J as oe,K as ne,n as z,h as te,H as g,C as V,p as ae,I as re,T as le,z as ie,d as v,b as P,B as ce}from"../index-DvNC5xiX.js";import{u as de}from"./user-DL8VbB5V.js";import{u as ue}from"./referrals-BDzxSJMj.js";import{a as N}from"./index-HW7Yk54d.js";import{g as me,b as pe,f as ge,s as E,a as fe}from"./index-oDv_V8If.js";import{s as q}from"./index-cJFiuVp4.js";import"./index-qFyJwsfU.js";import"./index-weadd45s.js";import"./index-CfKVozD1.js";const be={class:"mobile-profile fade-in"},ve={class:"user-card"},ye={class:"user-avatar"},we={class:"avatar-initial"},he={class:"user-info"},ke={class:"user-name"},Pe={class:"user-email"},ze={class:"stats-row"},_e={class:"stat-box"},Se={class:"stat-value"},$e={class:"stat-box"},xe={class:"stat-value"},je={class:"stat-box"},Ve={class:"stat-value"},Oe={class:"section-card"},Ie={key:0,class:"msg msg-success"},Me={key:1,class:"msg msg-error"},Be={class:"form-group"},Ce={class:"form-group"},Te={class:"form-group"},Ue=["disabled"],De={__name:"MobileProfile",setup(e){var T,U;const s=de(),n=ue(),{balance:a}=D(s),{referrals:b}=D(n),l=u(((T=window.paywayUser)==null?void 0:T.name)||"Пользователь"),r=u(((U=window.paywayUser)==null?void 0:U.email)||""),c=u(0),I=C(()=>l.value.charAt(0).toUpperCase()),H=C(()=>s.formatBalance),G=C(()=>{var m;return((m=b.value)==null?void 0:m.length)||0}),$=u(""),y=u(""),k=u(""),x=u(!1),j=u(""),w=u("");async function J(){var m,t,d;try{const M=await N.get("/projects");c.value=((t=(m=M.data)==null?void 0:m.data)==null?void 0:t.length)||((d=M.data)==null?void 0:d.length)||0}catch{c.value=0}}async function F(){var m,t;if(w.value="",j.value="",y.value!==k.value){w.value="Пароли не совпадают";return}if(y.value.length<6){w.value="Минимум 6 символов";return}x.value=!0;try{await N.post("/profile/update-password",{current_password:$.value,new_password:y.value,new_password_confirmation:k.value}),j.value="Пароль успешно изменён",$.value="",y.value="",k.value=""}catch(d){w.value=((t=(m=d.response)==null?void 0:m.data)==null?void 0:t.message)||"Ошибка при смене пароля"}finally{x.value=!1}}function Q(){localStorage.removeItem("jwtToken"),window.location.href="/account"}return Y(()=>{s.fetchBalance(),n.fetchMyReferrals(),J()}),(m,t)=>(i(),f("div",be,[o("div",ve,[o("div",ye,[o("span",we,p(I.value),1)]),o("div",he,[o("div",ke,p(l.value),1),o("div",Pe,p(r.value),1)])]),o("div",ze,[o("div",_e,[o("div",Se,p(H.value),1),t[3]||(t[3]=o("div",{class:"stat-label"},"Баланс",-1))]),o("div",$e,[o("div",xe,p(c.value),1),t[4]||(t[4]=o("div",{class:"stat-label"},"Проекты",-1))]),o("div",je,[o("div",Ve,p(G.value),1),t[5]||(t[5]=o("div",{class:"stat-label"},"Рефералы",-1))])]),o("div",Oe,[t[9]||(t[9]=o("div",{class:"section-title"},"Изменить пароль",-1)),j.value?(i(),f("div",Ie,p(j.value),1)):h("",!0),w.value?(i(),f("div",Me,p(w.value),1)):h("",!0),o("form",{onSubmit:R(F,["prevent"]),class:"password-form"},[o("div",Be,[t[6]||(t[6]=o("label",null,"Текущий пароль",-1)),O(o("input",{"onUpdate:modelValue":t[0]||(t[0]=d=>$.value=d),type:"password",placeholder:"Введите текущий пароль",class:"form-input",required:""},null,512),[[B,$.value]])]),o("div",Ce,[t[7]||(t[7]=o("label",null,"Новый пароль",-1)),O(o("input",{"onUpdate:modelValue":t[1]||(t[1]=d=>y.value=d),type:"password",placeholder:"Минимум 6 символов",class:"form-input",required:"",minlength:"6"},null,512),[[B,y.value]])]),o("div",Te,[t[8]||(t[8]=o("label",null,"Подтвердите пароль",-1)),O(o("input",{"onUpdate:modelValue":t[2]||(t[2]=d=>k.value=d),type:"password",placeholder:"Повторите новый пароль",class:"form-input",required:""},null,512),[[B,k.value]])]),o("button",{type:"submit",class:"btn-save",disabled:x.value},p(x.value?"Сохранение...":"Сохранить"),9,Ue)],32)]),o("button",{class:"btn-logout",onClick:Q},[...t[10]||(t[10]=[o("svg",{width:"18",height:"18",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2"},[o("path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"}),o("polyline",{points:"16 17 21 12 16 7"}),o("line",{x1:"21",y1:"12",x2:"9",y2:"12"})],-1),Z(" Выйти из аккаунта ",-1)])])]))}},Ne=X(De,[["__scopeId","data-v-00131b85"]]);var Ee=`
    .p-message {
        display: grid;
        grid-template-rows: 1fr;
        border-radius: dt('message.border.radius');
        outline-width: dt('message.border.width');
        outline-style: solid;
    }

    .p-message-content-wrapper {
        min-height: 0;
    }

    .p-message-content {
        display: flex;
        align-items: center;
        padding: dt('message.content.padding');
        gap: dt('message.content.gap');
    }

    .p-message-icon {
        flex-shrink: 0;
    }

    .p-message-close-button {
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        margin-inline-start: auto;
        overflow: hidden;
        position: relative;
        width: dt('message.close.button.width');
        height: dt('message.close.button.height');
        border-radius: dt('message.close.button.border.radius');
        background: transparent;
        transition:
            background dt('message.transition.duration'),
            color dt('message.transition.duration'),
            outline-color dt('message.transition.duration'),
            box-shadow dt('message.transition.duration'),
            opacity 0.3s;
        outline-color: transparent;
        color: inherit;
        padding: 0;
        border: none;
        cursor: pointer;
        user-select: none;
    }

    .p-message-close-icon {
        font-size: dt('message.close.icon.size');
        width: dt('message.close.icon.size');
        height: dt('message.close.icon.size');
    }

    .p-message-close-button:focus-visible {
        outline-width: dt('message.close.button.focus.ring.width');
        outline-style: dt('message.close.button.focus.ring.style');
        outline-offset: dt('message.close.button.focus.ring.offset');
    }

    .p-message-info {
        background: dt('message.info.background');
        outline-color: dt('message.info.border.color');
        color: dt('message.info.color');
        box-shadow: dt('message.info.shadow');
    }

    .p-message-info .p-message-close-button:focus-visible {
        outline-color: dt('message.info.close.button.focus.ring.color');
        box-shadow: dt('message.info.close.button.focus.ring.shadow');
    }

    .p-message-info .p-message-close-button:hover {
        background: dt('message.info.close.button.hover.background');
    }

    .p-message-info.p-message-outlined {
        color: dt('message.info.outlined.color');
        outline-color: dt('message.info.outlined.border.color');
    }

    .p-message-info.p-message-simple {
        color: dt('message.info.simple.color');
    }

    .p-message-success {
        background: dt('message.success.background');
        outline-color: dt('message.success.border.color');
        color: dt('message.success.color');
        box-shadow: dt('message.success.shadow');
    }

    .p-message-success .p-message-close-button:focus-visible {
        outline-color: dt('message.success.close.button.focus.ring.color');
        box-shadow: dt('message.success.close.button.focus.ring.shadow');
    }

    .p-message-success .p-message-close-button:hover {
        background: dt('message.success.close.button.hover.background');
    }

    .p-message-success.p-message-outlined {
        color: dt('message.success.outlined.color');
        outline-color: dt('message.success.outlined.border.color');
    }

    .p-message-success.p-message-simple {
        color: dt('message.success.simple.color');
    }

    .p-message-warn {
        background: dt('message.warn.background');
        outline-color: dt('message.warn.border.color');
        color: dt('message.warn.color');
        box-shadow: dt('message.warn.shadow');
    }

    .p-message-warn .p-message-close-button:focus-visible {
        outline-color: dt('message.warn.close.button.focus.ring.color');
        box-shadow: dt('message.warn.close.button.focus.ring.shadow');
    }

    .p-message-warn .p-message-close-button:hover {
        background: dt('message.warn.close.button.hover.background');
    }

    .p-message-warn.p-message-outlined {
        color: dt('message.warn.outlined.color');
        outline-color: dt('message.warn.outlined.border.color');
    }

    .p-message-warn.p-message-simple {
        color: dt('message.warn.simple.color');
    }

    .p-message-error {
        background: dt('message.error.background');
        outline-color: dt('message.error.border.color');
        color: dt('message.error.color');
        box-shadow: dt('message.error.shadow');
    }

    .p-message-error .p-message-close-button:focus-visible {
        outline-color: dt('message.error.close.button.focus.ring.color');
        box-shadow: dt('message.error.close.button.focus.ring.shadow');
    }

    .p-message-error .p-message-close-button:hover {
        background: dt('message.error.close.button.hover.background');
    }

    .p-message-error.p-message-outlined {
        color: dt('message.error.outlined.color');
        outline-color: dt('message.error.outlined.border.color');
    }

    .p-message-error.p-message-simple {
        color: dt('message.error.simple.color');
    }

    .p-message-secondary {
        background: dt('message.secondary.background');
        outline-color: dt('message.secondary.border.color');
        color: dt('message.secondary.color');
        box-shadow: dt('message.secondary.shadow');
    }

    .p-message-secondary .p-message-close-button:focus-visible {
        outline-color: dt('message.secondary.close.button.focus.ring.color');
        box-shadow: dt('message.secondary.close.button.focus.ring.shadow');
    }

    .p-message-secondary .p-message-close-button:hover {
        background: dt('message.secondary.close.button.hover.background');
    }

    .p-message-secondary.p-message-outlined {
        color: dt('message.secondary.outlined.color');
        outline-color: dt('message.secondary.outlined.border.color');
    }

    .p-message-secondary.p-message-simple {
        color: dt('message.secondary.simple.color');
    }

    .p-message-contrast {
        background: dt('message.contrast.background');
        outline-color: dt('message.contrast.border.color');
        color: dt('message.contrast.color');
        box-shadow: dt('message.contrast.shadow');
    }

    .p-message-contrast .p-message-close-button:focus-visible {
        outline-color: dt('message.contrast.close.button.focus.ring.color');
        box-shadow: dt('message.contrast.close.button.focus.ring.shadow');
    }

    .p-message-contrast .p-message-close-button:hover {
        background: dt('message.contrast.close.button.hover.background');
    }

    .p-message-contrast.p-message-outlined {
        color: dt('message.contrast.outlined.color');
        outline-color: dt('message.contrast.outlined.border.color');
    }

    .p-message-contrast.p-message-simple {
        color: dt('message.contrast.simple.color');
    }

    .p-message-text {
        font-size: dt('message.text.font.size');
        font-weight: dt('message.text.font.weight');
    }

    .p-message-icon {
        font-size: dt('message.icon.size');
        width: dt('message.icon.size');
        height: dt('message.icon.size');
    }

    .p-message-sm .p-message-content {
        padding: dt('message.content.sm.padding');
    }

    .p-message-sm .p-message-text {
        font-size: dt('message.text.sm.font.size');
    }

    .p-message-sm .p-message-icon {
        font-size: dt('message.icon.sm.size');
        width: dt('message.icon.sm.size');
        height: dt('message.icon.sm.size');
    }

    .p-message-sm .p-message-close-icon {
        font-size: dt('message.close.icon.sm.size');
        width: dt('message.close.icon.sm.size');
        height: dt('message.close.icon.sm.size');
    }

    .p-message-lg .p-message-content {
        padding: dt('message.content.lg.padding');
    }

    .p-message-lg .p-message-text {
        font-size: dt('message.text.lg.font.size');
    }

    .p-message-lg .p-message-icon {
        font-size: dt('message.icon.lg.size');
        width: dt('message.icon.lg.size');
        height: dt('message.icon.lg.size');
    }

    .p-message-lg .p-message-close-icon {
        font-size: dt('message.close.icon.lg.size');
        width: dt('message.close.icon.lg.size');
        height: dt('message.close.icon.lg.size');
    }

    .p-message-outlined {
        background: transparent;
        outline-width: dt('message.outlined.border.width');
    }

    .p-message-simple {
        background: transparent;
        outline-color: transparent;
        box-shadow: none;
    }

    .p-message-simple .p-message-content {
        padding: dt('message.simple.content.padding');
    }

    .p-message-outlined .p-message-close-button:hover,
    .p-message-simple .p-message-close-button:hover {
        background: transparent;
    }

    .p-message-enter-active {
        animation: p-animate-message-enter 0.3s ease-out forwards;
        overflow: hidden;
    }

    .p-message-leave-active {
        animation: p-animate-message-leave 0.15s ease-in forwards;
        overflow: hidden;
    }

    @keyframes p-animate-message-enter {
        from {
            opacity: 0;
            grid-template-rows: 0fr;
        }
        to {
            opacity: 1;
            grid-template-rows: 1fr;
        }
    }

    @keyframes p-animate-message-leave {
        from {
            opacity: 1;
            grid-template-rows: 1fr;
        }
        to {
            opacity: 0;
            margin: 0;
            grid-template-rows: 0fr;
        }
    }
`,qe={root:function(s){var n=s.props;return["p-message p-component p-message-"+n.severity,{"p-message-outlined":n.variant==="outlined","p-message-simple":n.variant==="simple","p-message-sm":n.size==="small","p-message-lg":n.size==="large"}]},contentWrapper:"p-message-content-wrapper",content:"p-message-content",icon:"p-message-icon",text:"p-message-text",closeButton:"p-message-close-button",closeIcon:"p-message-close-icon"},Ae=ee.extend({name:"message",style:Ee,classes:qe}),Ke={name:"BaseMessage",extends:pe,props:{severity:{type:String,default:"info"},closable:{type:Boolean,default:!1},life:{type:Number,default:null},icon:{type:String,default:void 0},closeIcon:{type:String,default:void 0},closeButtonProps:{type:null,default:null},size:{type:String,default:null},variant:{type:String,default:null}},style:Ae,provide:function(){return{$pcMessage:this,$parentInstance:this}}};function _(e){"@babel/helpers - typeof";return _=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(s){return typeof s}:function(s){return s&&typeof Symbol=="function"&&s.constructor===Symbol&&s!==Symbol.prototype?"symbol":typeof s},_(e)}function A(e,s,n){return(s=Le(s))in e?Object.defineProperty(e,s,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[s]=n,e}function Le(e){var s=Re(e,"string");return _(s)=="symbol"?s:s+""}function Re(e,s){if(_(e)!="object"||!e)return e;var n=e[Symbol.toPrimitive];if(n!==void 0){var a=n.call(e,s);if(_(a)!="object")return a;throw new TypeError("@@toPrimitive must return a primitive value.")}return(s==="string"?String:Number)(e)}var W={name:"Message",extends:Ke,inheritAttrs:!1,emits:["close","life-end"],timeout:null,data:function(){return{visible:!0}},mounted:function(){var s=this;this.life&&setTimeout(function(){s.visible=!1,s.$emit("life-end")},this.life)},methods:{close:function(s){this.visible=!1,this.$emit("close",s)}},computed:{closeAriaLabel:function(){return this.$primevue.config.locale.aria?this.$primevue.config.locale.aria.close:void 0},dataP:function(){return ge(A(A({outlined:this.variant==="outlined",simple:this.variant==="simple"},this.severity,this.severity),this.size,this.size))}},directives:{ripple:se},components:{TimesIcon:me}};function S(e){"@babel/helpers - typeof";return S=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(s){return typeof s}:function(s){return s&&typeof Symbol=="function"&&s.constructor===Symbol&&s!==Symbol.prototype?"symbol":typeof s},S(e)}function K(e,s){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);s&&(a=a.filter(function(b){return Object.getOwnPropertyDescriptor(e,b).enumerable})),n.push.apply(n,a)}return n}function L(e){for(var s=1;s<arguments.length;s++){var n=arguments[s]!=null?arguments[s]:{};s%2?K(Object(n),!0).forEach(function(a){We(e,a,n[a])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):K(Object(n)).forEach(function(a){Object.defineProperty(e,a,Object.getOwnPropertyDescriptor(n,a))})}return e}function We(e,s,n){return(s=He(s))in e?Object.defineProperty(e,s,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[s]=n,e}function He(e){var s=Ge(e,"string");return S(s)=="symbol"?s:s+""}function Ge(e,s){if(S(e)!="object"||!e)return e;var n=e[Symbol.toPrimitive];if(n!==void 0){var a=n.call(e,s);if(S(a)!="object")return a;throw new TypeError("@@toPrimitive must return a primitive value.")}return(s==="string"?String:Number)(e)}var Je=["data-p"],Fe=["data-p"],Qe=["data-p"],Xe=["aria-label","data-p"],Ye=["data-p"];function Ze(e,s,n,a,b,l){var r=oe("TimesIcon"),c=ne("ripple");return i(),z(le,g({name:"p-message",appear:""},e.ptmi("transition")),{default:te(function(){return[b.visible?(i(),f("div",g({key:0,class:e.cx("root"),role:"alert","aria-live":"assertive","aria-atomic":"true","data-p":l.dataP},e.ptm("root")),[o("div",g({class:e.cx("contentWrapper")},e.ptm("contentWrapper")),[e.$slots.container?V(e.$slots,"container",{key:0,closeCallback:l.close}):(i(),f("div",g({key:1,class:e.cx("content"),"data-p":l.dataP},e.ptm("content")),[V(e.$slots,"icon",{class:ae(e.cx("icon"))},function(){return[(i(),z(re(e.icon?"span":null),g({class:[e.cx("icon"),e.icon],"data-p":l.dataP},e.ptm("icon")),null,16,["class","data-p"]))]}),e.$slots.default?(i(),f("div",g({key:0,class:e.cx("text"),"data-p":l.dataP},e.ptm("text")),[V(e.$slots,"default")],16,Qe)):h("",!0),e.closable?O((i(),f("button",g({key:1,class:e.cx("closeButton"),"aria-label":l.closeAriaLabel,type:"button",onClick:s[0]||(s[0]=function(I){return l.close(I)}),"data-p":l.dataP},L(L({},e.closeButtonProps),e.ptm("closeButton"))),[V(e.$slots,"closeicon",{},function(){return[e.closeIcon?(i(),f("i",g({key:0,class:[e.cx("closeIcon"),e.closeIcon],"data-p":l.dataP},e.ptm("closeIcon")),null,16,Ye)):(i(),z(r,g({key:1,class:[e.cx("closeIcon"),e.closeIcon],"data-p":l.dataP},e.ptm("closeIcon")),null,16,["class","data-p"]))]})],16,Xe)),[[c]]):h("",!0)],16,Fe))],16)],16,Je)):h("",!0)]}),_:3},16)}W.render=Ze;const es={key:1,class:"p-3"},ss={class:"grid formgrid"},os={class:"col-12 mb-4"},ns={class:"col-12 mb-4"},ts={class:"col-12 mb-4"},as={class:"col-12 mb-4"},rs={class:"col-12 mt-3"},bs={__name:"ProfileView",setup(e){const{isMobile:s}=ie(),n=ce({name:"",email:"",password:"",repeatPassword:""}),a=u("");function b(){if(n.password!==n.repeatPassword){alert("Пароли не совпадают");return}a.value="Данные успешно сохранены!",console.log("Отправлено:",{...n}),Object.assign(n,{name:"",email:"",password:"",repeatPassword:""})}return(l,r)=>v(s)?(i(),z(Ne,{key:0})):(i(),f("div",es,[a.value?(i(),z(v(W),{key:0,severity:"success",text:a.value,class:"mb-4"},null,8,["text"])):h("",!0),o("form",{id:"payway-edit-profile-form",onSubmit:R(b,["prevent"]),autocomplete:"off"},[o("div",ss,[o("div",os,[r[4]||(r[4]=o("label",{for:"name",class:"block mb-2"},"Имя (Обязательно)",-1)),P(v(E),{id:"name",name:"name",modelValue:n.name,"onUpdate:modelValue":r[0]||(r[0]=c=>n.name=c),placeholder:"Ваше имя",required:"",class:"w-full"},null,8,["modelValue"])]),o("div",ns,[r[5]||(r[5]=o("label",{for:"email",class:"block mb-2"},"Почта (Обязательно)",-1)),P(v(E),{id:"email",name:"email",type:"email",modelValue:n.email,"onUpdate:modelValue":r[1]||(r[1]=c=>n.email=c),placeholder:"Ваш email",required:"",class:"w-full"},null,8,["modelValue"])]),o("div",ts,[r[6]||(r[6]=o("label",{for:"password",class:"block mb-2"},"Новый пароль",-1)),P(v(q),{id:"password",name:"password",modelValue:n.password,"onUpdate:modelValue":r[2]||(r[2]=c=>n.password=c),toggleMask:"",feedback:!1,class:"w-full"},null,8,["modelValue"])]),o("div",as,[r[7]||(r[7]=o("label",{for:"repeatPassword",class:"block mb-2"},"Повторите пароль",-1)),P(v(q),{id:"repeatPassword",name:"repeatPassword",modelValue:n.repeatPassword,"onUpdate:modelValue":r[3]||(r[3]=c=>n.repeatPassword=c),toggleMask:"",feedback:!1,class:"w-full"},null,8,["modelValue"])]),o("div",rs,[P(v(fe),{label:"Сохранить данные",icon:"pi pi-save",type:"submit",class:"p-button-success w-full"})])])],32)]))}};export{bs as default};
